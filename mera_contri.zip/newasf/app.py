from flask import Flask, render_template, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] ='sqlite:///users.db'

db = SQLAlchemy(app)

class Student(db.Model):
    __tablename__ = 'Student'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/intermed')
def interme():
    return render_template('intermed.html')

@app.route('/login', methods=['GET','POST'])
def login():
    users = Student.query.all()
    user_data = []
    for user in users:
        user_info = [user.username,user.password]
        user_data.append(user_info)
    username = request.form["username"]
    password = request.form["password"]
    if [username,password] in user_data:
        return "valid?"
    else:
        return "not valid"

if __name__ == "__main__":
    app.run(debug=True)